package com.example.project.controller;

import com.example.project.dto.MembersDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@Controller
@RequestMapping("/admin")
public class AdminController {

    @PostMapping("/memberList")
    public String getmemberList(@RequestParam int id, Model model) {
        return "admin/memberList";
    }

}
