package com.example.project.dto.user;

public class CarTypeCountDto {
    private String carType;
    private int carTypeCount;

    public String getCarType() {
        return carType;
    }

    public void setCarType(String carType) {
        this.carType = carType;
    }

    public int getCarTypeCount() {
        return carTypeCount;
    }

    public void setCarTypeCount(int carTypeCount) {
        this.carTypeCount = carTypeCount;
    }
}
