--When a user is not logged in, they need to be prevented from accessing the post upload function.

--Study again how to send objects or arrays to the server in JSON format.