package com.example.project.mapper;

import com.example.project.dto.AddressDto;
import com.example.project.dto.MembersDto;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

@Mapper
public interface MemberMapper {

    @Insert("INSERT INTO member_join VALUES (NULL, #{memberEmail}, #{memberPasswd}, #{memberName}, #{memberPhone}, #{memberNickName}, #{memberBirth}, #{memberPostcode}, #{memberAddress}, #{memberDetailAddress}, #{memberExtraAddress}, #{memberInterest}, now(), #{memberPoint}, '회원')")
    public void insertMember(MembersDto membersDto);

    @Select("SELECT COUNT(*) FROM member WHERE nickname = #{nickname}")
    public void nickNameCheck(String nickname);

    int NameCheck(String nickname);
}