package com.example.project.controller;

import com.example.project.dto.AddressDto;
import com.example.project.dto.MembersDto;
import com.example.project.mapper.MemberMapper;
import com.example.project.service.JoinService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@Controller
@RequestMapping("/member")
public class MemberController {

    @Autowired
    MemberMapper mm;

    @Autowired
    JoinService joinService;

    @GetMapping("/signup")
    public String getSignup() {
        return "member/signup";
    }

    @PostMapping("/signup")
    @ResponseBody
    public Map<String, Object> insertMember(@ModelAttribute MembersDto membersDto) {
        Map<String, Object> map = new HashMap<>();

        if(membersDto!= null) {

            mm.insertMember(membersDto);
            System.out.println(membersDto);
            map.put("message", "success");
        } else {
            map.put("message", "failure");
        }

        return map;
    }

    @GetMapping("/login")
    public String getLogin() {
        return "member/login";
    }


    @GetMapping("/nameCheck")
    @ResponseBody
    public Map<String, Object> getNameCheck(@RequestParam String nickName) {
        String result = joinService.nameCheck(nickName);
        System.out.println(joinService.nameCheck(nickName));
        return Map.of("msg", result);
    }

}
