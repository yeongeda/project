package com.example.project.service;

import com.example.project.mapper.MemberMapper;
import org.apache.ibatis.session.SqlSession;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class JoinService {

    @Autowired
    MemberMapper memberMapper;

    public String nameCheck(String nickName) {
        int result = memberMapper.nameCheck(nickName);

        String str = "";
        if(result > 0) {
            str = "No";
        }else {
            str = "Yes";
        }
        return str;
    }
}

