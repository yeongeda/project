package com.example.project.service;

import com.example.project.mapper.MemberMapper;
import org.springframework.beans.factory.annotation.Autowired;

public class JoinService {

//    @Autowired
//    JoinService joinService;
//
//    public static String checkNickName(String nickname) {
//        int result = MemberMapper.NameCheck(nickname);
//    }

    @Autowired
    private MemberMapper memberMapper;

    public boolean checkNickName(String nickname) {
        int count = memberMapper.NameCheck(nickname);
        return count == 0; // 0이면 사용 가능한 닉네임, 아니면 이미 사용 중인 닉네임
    }
}

