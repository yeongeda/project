package com.example.project.service;

import com.example.project.mapper.MemberMapper;
import org.apache.ibatis.session.SqlSession;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class JoinService {

    @Autowired
    MemberMapper memberMapper;

    public boolean checkNickName(String nickname) {
        int count = memberMapper.checkNickName(nickname);
        return count == 0;
    }
}

