package com.example.project.controller;

import com.example.project.dto.AddressDto;
import com.example.project.dto.MembersDto;
import com.example.project.mapper.MemberMapper;
import com.example.project.service.JoinService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.thymeleaf.util.StringUtils;

import java.time.DateTimeException;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;

@Controller
@RequestMapping("/member")
public class MemberController {

    @Autowired
    MemberMapper mm;

    @Autowired
    JoinService joinService;

    @GetMapping("/index")
    public String getIndexPage() {
        return "/member/index";
    }

    @GetMapping("/signup")
    public String getSignup() {
        return "member/signup";
    }

    @PostMapping("/signup")
    @ResponseBody
    public Map<String, Object> insertMember(@ModelAttribute MembersDto membersDto, @RequestParam("memberBirth") String memberBirth) {
        Map<String, Object> map = new HashMap<>();

        LocalDate birthDate = null;
        if (memberBirth != null && !memberBirth.trim().isEmpty()) {
            try {
                birthDate = LocalDate.parse(memberBirth);
            } catch (DateTimeException e) {
                e.printStackTrace();
            }
        }

        membersDto.setMemberBirth(birthDate);

        if (membersDto.getMemberEmail() == null || membersDto.getMemberEmail().isEmpty()) {
            map.put("message", "failure");
            map.put("error", "이메일을 입력하세요.");
            return map;
        } else {
            mm.insertMember(membersDto);
            System.out.println(membersDto);
            map.put("message", "success");
        }

        if (membersDto.getMemberPasswd() == null || membersDto.getMemberPasswd().isEmpty()) {
            mm.insertMember(membersDto);
            System.out.println(membersDto);
            map.put("message", "failure");
            map.put("error", "비밀번호가 유효하지 않습니다.");
        } else {
            map.put("message", "success");
        }

        return map;

    }

    @GetMapping("/login")
    public String getLogin() {
        return "/member/login";
    }

    @PostMapping("/login")
    public ResponseEntity<Map<String, Object>> login(@ModelAttribute MembersDto membersDto, HttpSession session) {
        String result = joinService.login(membersDto);
        Map<String, Object> response = new HashMap<>();

        if (result != null) {
            session.setAttribute("loggedInUser", result);
            response.put("success", true);
            response.put("user", result);
            return ResponseEntity.ok(response);
        } else {
            response.put("success", false);
            response.put("message", "아이디 또는 비밀번호를 확인해주세요");
            System.out.println("Login failed for user: " + membersDto.getMemberEmail());
            return ResponseEntity.ok(response); // 200 OK 상태 코드 반환
        }
    }

    @GetMapping("/nameCheck")
    @ResponseBody
    public Map<String, Object> getNameCheck(@RequestParam String nickName) {
        Map<String, Object> resultMap = new HashMap<>();
        String result = joinService.nameCheck(nickName);
//        System.out.println(joinService.nameCheck(nickName));
        resultMap.put("msg", result);

        return resultMap;
    }

    @GetMapping("/searchEmail")
    public String getSearchEmail() {
        return "/member/searchEmail";
    }

    @GetMapping("/resultEmail")
    public String resultEmail() {
        return "/member/resultEmail";
    }

    @PostMapping("/resultEmail")
    public String getResultEmail(@ModelAttribute MembersDto mdto, Model model) {
        model.addAttribute("result", mm.resultEmail(mdto.getMemberName(), mdto.getMemberPhone()));
        return "/member/resultEmail";
    }

    @GetMapping("/searchPasswd")
    public String getSearchPasswd() {
        return "/member/searchPasswd";
    }

    @GetMapping("/resultPasswd")
    public String getResultPasswd() {
        return "/member/resultPasswd";
    }

    @PostMapping("/resultPasswd")
    public String getResultPasswd(@ModelAttribute MembersDto mdto, Model model) {
        model.addAttribute("result", mm.resultPasswd(mdto.getMemberNickName(), mdto.getMemberEmail()));
        return "/member/resultPasswd";
    }

    @PostMapping("/emailCheck")
    @ResponseBody
    public int emailCheck(@RequestParam("memberEmail") String memberEmail) {
        int res = joinService.emailCheck(memberEmail);

        return res;
    }

    @PostMapping("/validatePhone")
    @ResponseBody
    public Map<String, Object> validatePhone(@RequestParam String phone) {
        Map<String, Object> result = new HashMap<>();

        // 전화번호 유효성 검사
        String phoneRegex = "^010([0-9]{8})$";
        if (phone.matches(phoneRegex)) {
            result.put("message", "success");
        } else {
            result.put("message", "failure");
            result.put("error", "전화번호 형식이 올바르지 않습니다.");
        }

        return result;
    }

    @PostMapping("/validatePassword")
    @ResponseBody
    public Map<String, Object> validatePassword(@RequestBody Map<String, String> passwordMap) {
        Map<String, Object> map = new HashMap<>();

        String password = passwordMap.get("password");

        map.put("message", "success");  // 예시: 성공적으로 처리되었음을 클라이언트에 알림
        return map;
    }

}

