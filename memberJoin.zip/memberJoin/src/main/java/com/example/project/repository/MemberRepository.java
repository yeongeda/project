package com.example.project.repository;

import com.example.project.dto.MembersDto;
import lombok.RequiredArgsConstructor;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;
import com.example.project.dto.MembersDto;
@Repository
@RequiredArgsConstructor
public class MemberRepository {


}
