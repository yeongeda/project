package com.example.project.dto;

import java.util.Date;

public class MembersDto {
    private int memberID;
    private String memberEmail;
    private String memberPasswd;
    private String memberName;
    private String memberPhone;
    private String memberNickName;
    private Date memberBirth;
    private String memberAddr;
    private String memberInterest;
    private Date regdate;

    public int getMemberID() {
        return memberID;
    }

    public void setMemberID(int memberID) {
        this.memberID = memberID;
    }

    public String getMemberEmail() {
        return memberEmail;
    }

    public void setMemberEmail(String memberEmail) {
        this.memberEmail = memberEmail;
    }

    public String getMemberPasswd() {
        return memberPasswd;
    }

    public void setMemberPasswd(String memberPasswd) {
        this.memberPasswd = memberPasswd;
    }

    public String getMemberName() {
        return memberName;
    }

    public void setMemberName(String memberName) {
        this.memberName = memberName;
    }

    public String getMemberPhone() {
        return memberPhone;
    }

    public void setMemberPhone(String memberPhone) {
        this.memberPhone = memberPhone;
    }

    public String getMemberNickName() {
        return memberNickName;
    }

    public void setMemberNickName(String memberNickName) {
        this.memberNickName = memberNickName;
    }

    public Date getMemberBirth() {
        return memberBirth;
    }

    public void setMemberBirth(Date memberBirth) {
        this.memberBirth = memberBirth;
    }

    public String getMemberAddr() {
        return memberAddr;
    }

    public void setMemberAddr(String memberAddr) {
        this.memberAddr = memberAddr;
    }

    public String getMemberInterest() {
        return memberInterest;
    }

    public void setMemberInterest(String memberInterest) {
        this.memberInterest = memberInterest;
    }

    public Date getRegdate() {
        return regdate;
    }

    public void setRegdate(Date regdate) {
        this.regdate = regdate;
    }

    @Override
    public String toString() {
        return "MembersDto{" +
                "memberID=" + memberID +
                ", memberEmail='" + memberEmail + '\'' +
                ", memberPasswd='" + memberPasswd + '\'' +
                ", memberName='" + memberName + '\'' +
                ", memberPhone='" + memberPhone + '\'' +
                ", memberNickName='" + memberNickName + '\'' +
                ", memberBirth=" + memberBirth +
                ", memberAddr='" + memberAddr + '\'' +
                ", memberInterest='" + memberInterest + '\'' +
                ", regdate=" + regdate +
                '}';
    }
}
