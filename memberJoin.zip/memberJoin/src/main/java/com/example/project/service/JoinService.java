package com.example.project.service;

import com.example.project.dto.MembersDto;
import com.example.project.mapper.MemberMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class JoinService {
    @Autowired
    MemberMapper memberMapper;

//    @Autowired
//    public JoinService(MemberRepository memberRepository) {
//        this.memberRepository = memberRepository;
//    }

    public String nameCheck(String nickName) {
        int result = memberMapper.nameCheck(nickName);

        String str = "";
        if(result > 0) {
            str = "No";
        }else {
            str = "Yes";
        }
        return str;
    }

    public MembersDto resultEmail(String memberName, String memberPhone) {

        return memberMapper.resultEmail(memberName, memberPhone);
    }

    public MembersDto resultPasswd(String memberNickName, String memberEmail) {
        return memberMapper.resultPasswd(memberNickName, memberEmail);
    }

    /*
    public String emailCheck(String memberEmail) {
        int result = memberMapper.emailCheck(memberEmail);

        String str = "";
        if(result > 0) {
            str = "N";
        }else {
            str = "Y";
        }
        return str;
    }*/

    public int emailCheck(String memberEmail) {
        int res = memberMapper.emailCheck(memberEmail);
        System.out.println("res: " + res);
        return res;
    }

    public String login(MembersDto membersDto) {
        String email = membersDto.getMemberEmail();
        String enteredPassword = membersDto.getMemberPasswd();

        // DB에서 저장된 패스워드를 가져옴
        String storedPassword = memberMapper.getPasswordByEmail(email);
        System.out.println("Entered Password: " + enteredPassword);
        System.out.println("Stored Password: " + storedPassword);

        // 비밀번호 일치 여부 확인
        if (storedPassword != null && storedPassword.equals(enteredPassword)) {
            // 패스워드 일치하면 로그인 성공
            return "success";
        } else {
            // 패스워드 불일치
            System.out.println("Login failed. Password mismatch.");
            return null;
        }
    }

}

