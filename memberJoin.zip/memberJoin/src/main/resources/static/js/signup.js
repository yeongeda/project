
document.addEventListener('DOMContentLoaded', function() {
        let btn = document.getElementById('sign');

        btn.addEventListener('click', function(e) {
            e.preventDefault();

            let emailInput = document.querySelector("#member_email input[type='text']");
            let passwdInput = document.querySelector("#member_passwd input[type='password']");
            let repasswdInput = document.querySelector("#member_repasswd input[type='password']");
            let nameInput = document.querySelector("#member_name input[type='text']");
            let phoneInput = document.querySelector("#member_phone input[type='text']");
            let nickNameInput = document.querySelector("#member_nickname input[type='text']");


            if(emailInput.value == "") {
                alert("이메일을 입력해주세요.")
                emailInput.focus();
                return false;
            }

            if(passwdInput.value == "") {
                alert("비밀번호를 입력해주세요.")
                passwdInpt.focus();
                return false;
            }

            if(repasswdInput.value == "") {
                alert("비밀번호 확인란을 입력해주세요.")
                repasswdInput.focus();
                return false;
            }

            if(nameInput.value == "") {
                alert("이름을 입력해주세요.")
                nameInput.focus();
                return false;
            }

            if(phoneInput.value == "") {
                alert("휴대폰 번호를 입력해주세요.")
                phoneInput.focus();
                return false;
            }

            if(nickNameInput.value == "") {
                alert("닉네임을 입력해주세요.")
                nickNameInput.focus();
                return false;
            }


            let dom = $('#email').val() + "@" + $('#domain').val();
            let obj = {
                memberEmail: dom,
                memberPasswd: $('#passwd').val(),
                memberName: $('#name').val(),
                memberPhone: $('#phone').val(),
                memberNickName: $('#nickName').val(),
                memberBirth: $('#date').val(),
                memberPostcode: $('#postcode').val(),
                memberAddress: $('#address').val(),
                memberDetailAddress : $('#detailAddress').val(),
                memberExtraAddress : $('#extraAddress').val(),
                memberInterest: $("input[name='chk_hobby']:checked").val() // 선택된 관심 항목의 값을 가져옴
            };

            console.log(obj);
            $.ajax({
                type: "post",
                url: "/member/signup",
                dataType: "json",
                data: obj,
                success: function(res) {
                    if (res.message === "success") {
                        alert("회원 가입이 완료되었습니다.");
                        location.href = "/member/login";
                    }else if (res.message === "failure"){
                        alert("회원 가입에 실패했습니다.");
                        location.href = "/member/signup";
                    }
                }
            });
        });
    });

/* ------------------------ 에러 메세지 객체 ----------------------------- */
      let errMsg = {
        pw: "8~20자(영문, 숫자, 특수문자)모두 포함해주세요",
        pwRe: {
          success: "비밀번호가 일치합니다",
          fail: "비밀번호가 일치하지 않습니다"
        },
        phone: {
            invalid: "‘-’ 제외 11자리를 입력해주세요"
        },
        birth: {
            fail: "올바른 생년월일 형식이 아닙니다"
        }
      }

/*---------------------- email 유효성 검사(중복확인) onchange 사용  -----------------------*/

    function checkEmail() {
        var memberEmail = $('#email').val();
        var domain = $('#domain').val();
        var domainList = $('#domain-list').val();
        var errorMsg = $("#emailCheck .error-msg");

        if (domainList !== 'type') {
            memberEmail += '@' + domainList;
        } else if (domain) {
            memberEmail += '@' + domain;
        }  else {
            // 도메인이 없는 경우 중복 체크를 수행하지 않음
            errorMsg.text('');
            return;
        }

        $.ajax({
            url: './emailCheck',
            type: 'post',
            dataType: 'json',
            data: { memberEmail : memberEmail},
            success: function(res) {
                console.log('Server Response:', res);
                if(res === 0) {
                    errorMsg.text('중복되지 않은 이메일입니다.');
                    errorMsg.css('color', 'rgb(46, 122, 46)');
                } else {
                    errorMsg.text('중복된 이메일입니다.');
                    errorMsg.css('color', 'red');
                }
            },
            error:function(){
                alert("에러입니다");
            }
        });
    }

/* -------------------------  email 도메인 선택시 옆칸에 선택한 도메인 입력됨 ---------------------  */

     let domainList = document.querySelector('#domain-list')
     let domainInput = document.querySelector('#domain')

     domainList.addEventListener('change', (event) => {
     // option에 있는 도메인 선택
         if(event.target.value !== "type") {
             // 선택한 도메인을 input에 입력하고 disabled
             domainInput.value = event.target.value
             domainInput.disabled = true
         } else { // 직접 입력
             // input 내용 초기화 & 입력 가능하도록 변경
             domainInput.value = ""
             domainInput.disabled = false
         }
     });

/* ----------------------------------- phone 유효성 검사 ------------------------------------ */


    let account = {};   //account 쓰기 위해 전역으로 넣어놓음.

    let phoneInput = document.querySelector('#member_phone input')
    let phoneErrorMsg = document.querySelector('#member_phone .error-msg')
    phoneInput.addEventListener('change', () => {
      let phoneReg =/^010([0-9]{8})$/
      if(phoneReg.test(phoneInput.value)) {
        phoneErrorMsg.textContent = ""
        account.phone = phoneInput.value
      } else {
        phoneErrorMsg.textContent = errMsg.phone.invalid
        account.phone = null
      }
        console.log(account)
      });

/* ---------------------------------- passwd 조건에 부합 ---------------------------------- */

      // pwVal: 패스워드, pwdReVal: 패스워드 재입력, isPwdValid: 패스워드 유효 여부

      let pwdVal = "", pwdReVal = "", isPwdValid = false
      let pwdInput = document.querySelector('#member_passwd input')
      let pwdErrorMsg = document.querySelector('#member_passwd .error-msg')

      pwdInput.addEventListener('change', () => {
        let pwdReg = /^(?=.*[A-Za-z])(?=.*[0-9])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{8,20}$/
        pwdVal = pwdInput.value
        if(pwdReg.test(pwdInput.value)) { // 정규식 조건 만족 O
          isPwdValid = true
          pwdErrorMsg.textContent = ""
        }
        else { // 정규식 조건 만족 X
          isPwdValid = false
          pwdErrorMsg.textContent = errMsg.pw
        }
        checkPwdValid()
        console.log(pwdVal, pwdReVal, isPwdValid, account)
      });

/* -------------------------- repassw와 passwd값 일치 검사 ----------------------------- */

      let pwdReInput = document.querySelector('#member_repasswd input')
      let pwdReErrorMsg = document.querySelector('#member_repasswd .error-msg')

      pwdReInput.addEventListener('change', () => {
        pwdReVal = pwdReInput.value
        checkPwdValid()
        console.log(pwdVal, pwdReVal, isPwdValid, account)
      });

      // 비밀번호와 재입력 값 일치 여부
      function checkPwdValid() {
        account.pw = null // default null 처리
        if(pwdReVal === '') { // 미입력
          pwdReErrorMsg.textContent = ""
        } else if(pwdVal === pwdReVal) { // 비밀번호 재입력 일치
              if(isPwdValid) {
                account.pw = pwdVal
              }
              pwdReErrorMsg.style.color = "green"
              pwdReErrorMsg.textContent = errMsg.pwRe.success
        } else { // 비밀번호 재입력 불일치
          pwdReErrorMsg.style.color = "red"
          pwdReErrorMsg.textContent = errMsg.pwRe.fail
        }
    }


/* -------------------------- 닉네임 중복확인  ------------------------------ */

        let nickInput = document.querySelector("#nickName");
        let nameCheckBtn = document.querySelector("#nameChk");
        let errorMsg = $("#member_nickname .error-msg");
        let nameChecked = false;

        // 중복 확인 버튼 클릭 시 중복 확인
        nameCheckBtn.addEventListener('click', (e) => {
            e.preventDefault();
            nameCheck();
        });

        function nameCheck() {
            $.ajax({
                type: "get",
                url: "/member/nameCheck",
                data: { "nickName": nickInput.value },
                success: function(res) {
                    let message = res.msg;

                    if (res.msg == "Yes") {
                        errorMsg.text('사용가능한 닉네임입니다.');
                        errorMsg.css('color', 'green');
                        nameChecked = true;
                    } else {
                        errorMsg.text('이미 사용중인 닉네임입니다.')
                        errorMsg.css('color', 'red');
                        nameChecked = false;
                    }
                }
            });
        }

        let signUpBtn = document.getElementById('sign');

        signUpBtn.addEventListener('click', function(e) {
            e.preventDefault();

            if (!nameChecked) {
                alert("닉네임 중복 확인을 해주세요.");
                return;
            }
        });

/* --------------------------- 생년월일 yyyy-MM-dd 형식 받기 --------------------------- */

    let dateInput = document.querySelector("#date");
    let birthErrorMsg = document.querySelector('#member_birth .error-msg');


    dateInput.addEventListener('input', () => {
        let val = dateInput.value.replace(/\D/g, "");
        let leng = val.length;
        let result = '';

        if (leng < 6) result = val;
        else if (leng < 8) {
            result += val.substring(0, 4);
            result += "-";
            result += val.substring(4);
        } else {
            result += val.substring(0, 4);
            result += "-";
            result += val.substring(4, 6);
            result += "-";
            result += val.substring(6);

                if (!checkValidDate(result)) {
                    birthErrorMsg.style.color = "red";
                    birthErrorMsg.textContent = errMsg.birth.fail;
                } else {
                    birthErrorMsg.textContent = "";
                }

        }
        dateInput.value = result;


    });
    const checkValidDate = (value) => {
        let result = true;
        try {
            let date = value.split("-");
            let y = parseInt(date[0], 10),
                m = parseInt(date[1], 10),
                d = parseInt(date[2], 10);

            let dateRegex =  /^(?=\d)(?:(?:31(?!.(?:0?[2469]|11))|(?:30|29)(?!.0?2)|29(?=.0?2.(?:(?:(?:1[6-9]|[2-9]\d)?(?:0[48]|[2468][048]|[13579][26])|(?:(?:16|[2468][048]|[3579][26])00)))(?:\x20|$))|(?:2[0-8]|1\d|0?[1-9]))([-.\/])(?:1[012]|0?[1-9])\1(?:1[6-9]|[2-9]\d)?\d\d(?:(?=\x20\d)\x20|$))?(((0?[1-9]|1[012])(:[0-5]\d){0,2}(\x20[AP]M))|([01]\d|2[0-3])(:[0-5]\d){1,2})?$/;
            result = dateRegex.test(d + '-' + m + '-' + y);
        } catch (err) {
            result = false;
        }
        return result;
    };


/* ---------------------------------- 주소 우편번호 api ---------------------------------- */
      function Postcode() {
         new daum.Postcode({
             oncomplete: function(data) {

                 // 각 주소의 노출 규칙에 따라 주소를 조합한다.
                 // 내려오는 변수가 값이 없는 경우엔 공백('')값을 가지므로, 이를 참고하여 분기 한다.
                 var addr = ''; // 주소 변수
                 var extraAddr = ''; // 참고항목 변수

                 //사용자가 선택한 주소 타입에 따라 해당 주소 값을 가져온다.
                 if (data.userSelectedType === 'R') { // 사용자가 도로명 주소를 선택했을 경우
                     addr = data.roadAddress;
                 } else { // 사용자가 지번 주소를 선택했을 경우(J)
                     addr = data.jibunAddress;
                 }

                 // 사용자가 선택한 주소가 도로명 타입일때 참고항목을 조합한다.
                 if(data.userSelectedType === 'R'){
                     // 법정동명이 있을 경우 추가한다.
                     // 법정동의 경우 마지막 문자가 "동/로/가"로 끝난다.
                     if(data.bname !== '' && /[동|로|가]$/g.test(data.bname)){
                         extraAddr += data.bname;
                     }
                     if(data.buildingName !== '' && data.apartment === 'Y'){
                         extraAddr += (extraAddr !== '' ? ', ' + data.buildingName : data.buildingName);
                     }
                     // 표시할 참고항목이 있을 경우, 괄호까지 추가한 최종 문자열을 만든다.
                     if(extraAddr !== ''){
                         extraAddr = ' (' + extraAddr + ')';
                     }
                     // 조합된 참고항목을 해당 필드에 넣는다.
                     document.getElementById("extraAddress").value = extraAddr;

                 } else {
                     document.getElementById("extraAddress").value = '';
                 }

                 // 우편번호와 주소 정보를 해당 필드에 넣는다.
                 document.getElementById("postcode").value = data.zonecode;
                 document.getElementById("address").value = addr;
                 // 커서를 상세주소 필드로 이동한다.
                 document.getElementById("detailAddress").focus();
             }
         }).open();
     }