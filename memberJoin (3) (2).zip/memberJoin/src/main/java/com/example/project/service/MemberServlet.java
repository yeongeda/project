package com.example.project.service;

import jakarta.servlet.annotation.WebServlet;

@WebServlet("/signup")
public class MemberServlet {

    /*
    private void doHandle(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");
        response.setContentType("text/html; Charset=utf-8");
        PrintWriter writer = response.getWriter();
        String nickName = (String)request.getParameter("nickname");

        System.out.println("nickName = " + nickName);
        MemberDAO memberDAO = new MemberDAO();
        boolean overlappednickName = memberDAO.overlappednickName(nickName);

        if(overlappednickName == true) {
            writer.print("not_usable");
        }else {
            writer.print("usable");
        }
    }

     */
}
